﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SEPRO.APP.Extensions;
using SEPRO.APP.Models;

namespace SEPRO.APP.Controllers;

/// <summary>
///     Contrôleur principal de l'application qui gère les requêtes HTTP pour les vues principales et les erreurs.
/// </summary>
/// <param name="logger">Service de journalisation utilisé pour enregistrer les informations de journalisation.</param>
[Controller]
[Route("[action]")]
[Route("[controller]/[action]")]
public class HomeController(ILogger<HomeController> logger) : Controller
{
    [Route("/")]
    [Route("/Home")]
    public IActionResult Index()
    {
        logger.LogInformation("C'est ici que tout commence!");

        return View()
            .WithToastSuccess(
                "Bienvenue!",
                "Bienvenue sur <b>SEPRO.APP</b>, vous pouvez commencer à coder <i class=\"fa-solid fa-face-smile-wink\"></i> "
            );
    }

    [HttpGet("{id:int}")] // GET /Home/Privacy/{id}
    public IActionResult Privacy(int id)
    {
        return Ok(id);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel
            { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}