﻿namespace SEPRO.APP.Models.ViewModels;

// ReSharper disable once InconsistentNaming
#pragma warning disable IDE1006
public class _HeaderVM
#pragma warning restore IDE1006
{
    public IList<_MenuItemVM> MenuItems { get; set; } = new List<_MenuItemVM>();
}