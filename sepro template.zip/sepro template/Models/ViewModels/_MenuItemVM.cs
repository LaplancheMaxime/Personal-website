﻿using SEPRO.APP.Exceptions;

namespace SEPRO.APP.Models.ViewModels;

// ReSharper disable once InconsistentNaming
#pragma warning disable IDE1006
public class _MenuItemVM
#pragma warning restore IDE1006
{
    public _MenuItemVM(
        string? action, string? controller, string? url,
        string? title = null,
        string? logo = null,
        IList<_MenuItemVM>? subMenuItemsItemVms = null
    )
    {
        if (string.IsNullOrWhiteSpace(action) && subMenuItemsItemVms is null)
            throw new ActionUrlNotFoundException("Une action est nécessaire pour la génération d'un item de menu");

        if (string.IsNullOrWhiteSpace(controller) && subMenuItemsItemVms is null)
            throw new ActionUrlNotFoundException(
                $"Il faut préciser le controlleur, il est nécessaire pour la génération d'un item de menu vers l'action {action}");

        if (string.IsNullOrWhiteSpace(url) && subMenuItemsItemVms is null)
            throw new ActionUrlNotFoundException(
                $"Le lien vers le controlleur {controller} et vers l'action {action} n'est pas correct");

        Url = url;
        Action = action;
        Controller = controller;
        Title = title;
        Logo = logo;
        SubMenuItemsItemVms = subMenuItemsItemVms;
    }

    public string? Url { get; set; }
    public string? Action { get; set; }
    public string? Controller { get; set; }
    public string? Title { get; set; }
    public string? Logo { get; set; }
    public IList<_MenuItemVM>? SubMenuItemsItemVms { get; set; }
}