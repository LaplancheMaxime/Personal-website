﻿namespace SEPRO.APP.Exceptions;

public class ActionUrlNotFoundException : Exception
{
    public ActionUrlNotFoundException()
    {
    }

    public ActionUrlNotFoundException(string? message) : base(message)
    {
    }

    public ActionUrlNotFoundException(string? message, Exception? innerException) : base(message, innerException)
    {
    }
}