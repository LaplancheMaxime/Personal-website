﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SEPRO.APP.Helpers;

namespace SEPRO.APP.Extensions;

public static class CommonViews
{
    public static IActionResult WithToastSuccess(this IActionResult result, string title, string body)
    {
        return Toast(result, "success", title, body);
    }

    public static IActionResult WithToastInfo(this IActionResult result, string title, string body)
    {
        return Toast(result, "info", title, body);
    }

    public static IActionResult WithToastWarning(this IActionResult result, string title, string body)
    {
        return Toast(result, "warning", title, body);
    }

    public static IActionResult WithToastDanger(this IActionResult result, string title, string body)
    {
        return Toast(result, "danger", title, body);
    }

    private static IActionResult Toast(IActionResult result, string type, string title, string body)
    {
        return new ToastDecoratorResult(result, type, title, body);
    }

    public static string IsSelected(this IHtmlHelper html, string controller = "", string action = "",
        string cssClass = "active")
    {
        if (string.IsNullOrEmpty(cssClass)) cssClass = "active";
        var currentAction = (string?)html.ViewContext.RouteData.Values["action"] ?? "";
        var currentController = (string?)html.ViewContext.RouteData.Values["controller"] ?? "";
        if (string.IsNullOrWhiteSpace(controller)) controller = currentController;
        if (string.IsNullOrWhiteSpace(action)) action = currentAction;
        return controller == currentController && action == currentAction ? cssClass : string.Empty;
    }

    public static string PageClass(this IHtmlHelper html)
    {
        var currentAction = (string?)html.ViewContext.RouteData.Values["action"] ?? "";
        return currentAction;
    }
}