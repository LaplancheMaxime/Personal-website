﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace SEPRO.APP.Helpers;

public class ToastDecoratorResult : IActionResult
{
    public ToastDecoratorResult(IActionResult result, string type, string title, string body)
    {
        Result = result;
        Type = type;
        Title = title;
        Body = body;
    }

    public IActionResult Result { get; }
    public string Type { get; }
    public string Title { get; }
    public string Body { get; }

    public async Task ExecuteResultAsync(ActionContext context)
    {
        //NOTE: Be sure you add a using statement for Microsoft.Extensions.DependencyInjection, otherwise
        //      this overload of GetService won't be available!
        var factory = context.HttpContext.RequestServices.GetService<ITempDataDictionaryFactory>();

        var tempData = factory!.GetTempData(context.HttpContext);
        tempData["_toast.type"] = Type;
        tempData["_toast.title"] = Title;
        tempData["_toast.body"] = Body;

        await Result.ExecuteResultAsync(context);
    }
}